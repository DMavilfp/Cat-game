// Копирует шрифты Comfortaa и Nunito (кириллица и латиница) из npm-пакетов в www/fonts
// и пишет www/fonts.css, чтобы игра выглядела одинаково без интернета.
// Если файла нет, шаг просто пропускается: игра откроется с системными шрифтами.
const fs = require('fs');
const path = require('path');

const out = path.join('www', 'fonts');
fs.mkdirSync(out, { recursive: true });

const wanted = [
  { pkg: 'comfortaa', family: 'Comfortaa', weights: [600, 700] },
  { pkg: 'nunito', family: 'Nunito', weights: [500, 700, 800] },
];
const ranges = {
  cyrillic: 'U+0301,U+0400-045F,U+0490-0491,U+04B0-04B1,U+2116',
  latin: 'U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD',
};

let css = '';
let faces = 0;
for (const w of wanted) {
  const dir = path.join('node_modules', '@fontsource', w.pkg, 'files');
  for (const weight of w.weights) {
    for (const subset of Object.keys(ranges)) {
      const name = `${w.pkg}-${subset}-${weight}-normal.woff2`;
      const src = path.join(dir, name);
      if (!fs.existsSync(src)) {
        console.warn('нет файла шрифта:', name);
        continue;
      }
      fs.copyFileSync(src, path.join(out, name));
      css += `@font-face{font-family:'${w.family}';font-style:normal;font-weight:${weight};font-display:swap;src:url(fonts/${name}) format('woff2');unicode-range:${ranges[subset]}}\n`;
      faces++;
    }
  }
}
fs.writeFileSync(path.join('www', 'fonts.css'), css || '/* системные шрифты */\n');
console.log(`fonts.css готов, начертаний: ${faces}`);
